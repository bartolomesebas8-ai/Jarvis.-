# JARVIS 0.3 - base de motores

Esta versión conserva la memoria local de JARVIS 0.2 y añade una arquitectura común para seleccionar un motor de IA.

- `AiEngine`: contrato común para motores.
- `GroqEngine`: adaptador provisional; NO realiza llamadas a Groq todavía. La clave API no se guarda en la APK.
- `QwenEngine`: adaptador provisional; NO se conecta todavía a PocketPal porque no se ha confirmado una API local.
- `AiEngineRouter`: punto único para elegir modo online u offline.

## Estado real

La memoria local sigue implementada en `MainActivity.kt` mediante `SharedPreferences`. Groq, Qwen, voz y servidor intermediario todavía no están integrados. No introduzcas claves API en el repositorio ni en la aplicación Android.
