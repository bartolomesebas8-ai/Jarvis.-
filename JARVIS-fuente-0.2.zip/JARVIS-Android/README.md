# JARVIS Android — versión inicial

Proyecto Android nativo que genera una APK de prueba mediante GitHub Actions.

Incluye una interfaz de chat de demostración y compilación automática. Todavía no conecta Groq ni Qwen/PocketPal.

## Compilar
Sube todos los archivos de este proyecto al repositorio `JARVIS`, rama `main`. Luego abre **Acciones**, ejecuta **Construir APK de JARVIS** y descarga el artefacto `JARVIS-debug`.

No subas claves API al repositorio ni las incluyas en una APK pública. La conexión online segura necesita un backend; integrar Qwen local requiere un runtime compatible dentro de la app.
